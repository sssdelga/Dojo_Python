from django.shortcuts import render

def index(request):
    return render(request, 'index.html')

def result(request):
    if request.method == 'POST':
        context = {
            'ur_name': request.POST['ur_name'],
            'dojo_location': request.POST['dojo_location'],
            'fav_lang': request.POST['fav_lang']
        }
        return render(request, 'result.html', context)
    return render(request, 'result.html')

