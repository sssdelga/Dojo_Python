from django.apps import AppConfig


class NinjagoldAppConfig(AppConfig):
    name = 'ninjagold_app'
