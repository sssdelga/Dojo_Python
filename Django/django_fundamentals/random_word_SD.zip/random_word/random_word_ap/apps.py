from django.apps import AppConfig


class RandomWordApConfig(AppConfig):
    name = 'random_word_ap'
