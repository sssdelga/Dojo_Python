from django.apps import AppConfig


class LogRegAppConfig(AppConfig):
    name = 'log_reg_app'
